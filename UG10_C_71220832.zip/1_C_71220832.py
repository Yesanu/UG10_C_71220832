#SOAL 1
print("========== PILIH MENU ==========")
print("1. Tambah")
print("2. Kurang")
print("3. Kali")
print("4. Bagi")
#RUMUS
opsi = int(input("Masukan Pilihan Operasi : "))
Bil1 = int(input("Bilangan 1 : "))
Bil2 = int(input("Bilangan 2 : "))
if opsi == 1:
   hasil = Bil1+Bil2
elif opsi == 2:
   hasil = Bil1-Bil2
elif opsi == 3:
   hasil = Bil1*Bil2
elif opsi == 4:
   hasil = Bil1/Bil2
print("Hasil : %d" %hasil)
