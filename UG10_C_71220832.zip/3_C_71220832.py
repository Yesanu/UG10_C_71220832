pesanan = input("Masukkan Daftar Pesanan : ")
if "eskrim" or "es teh" or "putih" in pesanan
    print("Daftar Pesanan : ['Eskrim','Es Teh','Putih']")


