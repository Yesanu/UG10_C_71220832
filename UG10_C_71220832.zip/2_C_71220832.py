#SOAL NOMOR 2
bulan = input("Masukkan Bulan (1-12): ")
#RUMUS
if "2" in bulan :
    print("Jumlah Hari: 28")
elif "1" or "3" or "5" or "7" or "8" or "9" or "11" in bulan :
    print ("Jumlah Hari: 31")
elif "4" or "6" or "10" or "12" in bulan :
    print ("Jumlah Hari: 30")

